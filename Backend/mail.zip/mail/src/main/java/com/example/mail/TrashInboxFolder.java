package com.example.mail;

import java.util.ArrayList;

public class TrashInboxFolder implements MailFolders{
    @Override
    public void addMail(Mail mail) {

    }

    @Override
    public ArrayList<Mail> getMail() {
        return null;
    }

    @Override
    public ArrayList<Mail> deleteMail(Mail mail) {
        return null;
    }
}
